<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Delete post',
'Warning'				=>	'Warning! If this is the first post in the topic, the whole topic will be deleted.',
'Delete'				=>	'Delete',	// The submit button
'Post del redirect'		=>	'Post deleted. Redirecting &hellip;',
'Topic del redirect'	=>	'Topic deleted. Redirecting &hellip;'

);
