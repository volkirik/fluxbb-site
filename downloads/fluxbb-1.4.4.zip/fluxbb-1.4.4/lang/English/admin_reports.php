<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Report marked as read. Redirecting …',
'New reports head'			=>	'New reports',
'Deleted user'				=>	'Deleted user',
'Deleted'					=>	'Deleted',
'Report subhead'			=>	'Reported %s',
'Reported by'				=>	'Reported by %s',
'Reason'					=>	'Reason',
'Zap'						=>	'Mark as read',
'No new reports'			=>	'There are no new reports.',
'Last 10 head'				=>	'10 last read reports',
'NA'						=>	'N/A',
'Zapped subhead'			=>	'Marked as read %s by %s',
'No zapped reports'			=>	'There are no read reports.',

);
