<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Post new topic',
'Views'			=>	'Views',
'Moved'			=>	'Moved:',
'Sticky'		=>	'Sticky:',
'Closed'		=>	'Closed:',
'Empty forum'	=>	'Forum is empty.',
'Mod controls'	=>	'Moderator controls'

);
