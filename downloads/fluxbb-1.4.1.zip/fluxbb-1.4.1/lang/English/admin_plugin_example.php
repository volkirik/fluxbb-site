<?php

// Language definitions used in example Plugin
$lang_admin_plugin_example = array(

'No text'				=>	'You didn\'t enter anything!',
'Example plugin title'	=>	'Example plugin',
'You said'				=>	'You said "%s". Great stuff.',
'Explanation 1'			=>	'This plugin doesn\'t do anything useful. Hence the name "Example".',
'Explanation 2'			=>	'This would be a good spot to talk a little about your plugin. Describe what it does and how it should be used. Be brief, but informative.',
'Example form title'	=>	'An example form',
'Legend text'			=>	'Enter a piece of text and hit "Show text"!',
'Text to show'			=>	'Text to show',
'Show text button'		=>	'Show text',
'Input content'			=>	'The text you want to display.',

);
