<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Report zapped. Redirecting …',
'New reports head'			=>	'New reports',
'Deleted user'				=>	'Deleted user',
'Deleted'					=>	'Deleted',
'Report subhead'			=>	'Reported %s',
'Reported by'				=>	'Reported by %s',
'Reason'					=>	'Reason',
'Zap'						=>	'Zap',
'No new reports'			=>	'There are no new reports.',
'Last 10 head'				=>	'10 last zapped reports',
'NA'						=>	'N/A',
'Zapped subhead'			=>	'Zapped %s by %s',
'No zapped reports'			=>	'There are no zapped reports.',

);