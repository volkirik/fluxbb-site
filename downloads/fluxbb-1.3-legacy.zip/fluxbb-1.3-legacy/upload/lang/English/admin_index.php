<?php

$lang_admin_index = array(

'Information head'				=>	'Welcome to FluxBB administration control panel',
'Alerts'						=>	'Administrator Alerts',
'Check for updates enabled'		=>	'This board is setup to automatically check for updates and hotfixes against the FluxBB.org updates service.',
'Check for updates manual'		=>	'Check for updates',	// Link text
'FluxBB version'				=>	'FluxBB version',
'Not available'					=>	'Not available',
'Not applicable'				=>	'N/A',
'Server load'					=>	'Server load',
'users online'					=>	'users online',
'Environment'					=>	'Environment',
'Operating system'				=>	'Operating system',
'Show info'						=>	'Show info',
'Accelerator'					=>	'Accelerator',
'Database'						=>	'Database',
'Rows'							=>	'Rows',
'Size'							=>	'Size',
'phpinfo disabled'				=>	'The PHP function phpinfo() has been disabled on this server.',

);